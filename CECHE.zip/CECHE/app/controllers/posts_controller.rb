class PostsController < ApplicationController
  def index
    @posts = Post.all
  end
  def show
    @post = Post.find_by(id: params[:id])
  end
  def new

  end
  def create
    @post = Post.new({
      title: params[:title],
      body: params[:body],
      user_id: params[:user_id]
      })
    if @post.save
      flash[:success] = "Post created"
      redirect_to "/posts/#{@post.id}"
    else
      flash[:warning] = "Post not created"
      render :new
    end
  end
  def edit
    @post = Post.find_by(id: params[:id])

  end
  def update
    @post = Post.find_by(id: params[:id])
    @post.assign_attributes({
      title: params[:title],
      body: params[:body],
      user_id: params[:user_id]
      })
    if @post.save
      flash[:success] = "Post saved"
      redirect_to "/posts/#{@post.id}"
    else
      @posts = Post.all
      render :edit
    end
  end
  def destroy
    @post = Post.find_by(id: params[:id])
    @post.destroy
    flash[:warning] = "Post deleted"
    redirect_to "/posts"
  end
  
end
