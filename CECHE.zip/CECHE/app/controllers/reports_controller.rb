class ReportsController < ApplicationController
  def new
    @report = Report.new
  end
  def create
    @report = Report.new(
      title: params[:title],
      image: params[:image]
      )
    if @report.save 
      flash[:success] = "Report uploaded"
      redirect_to "/reports/#{@report.id}"
    else
      flash[:danger] = "Report not uploaded"
      render :new
    end
  end 
  def show
    @report = Report.find_by(id: params[:id])
  end


  def edit
    @report = Report.find_by(id: params[:id])
  end
  def update
    @report = Report.find_by(id: params[:id])
    @report.assign_attributes(title: params[:title], image: params[:image])
    if @report.save
      flash[:success] = "Report Updated"  
      redirect_to "/reports/#{@report.id}"
    else
      render :edit
    end

  end
  def destroy
    @report = Report.find_by(id: params[:id])
    @report.destroy
    flash[:warning] = "Report deleted"
    redirect_to "/reports"
  end
  
end

