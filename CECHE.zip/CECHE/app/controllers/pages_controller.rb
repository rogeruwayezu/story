class PagesController < ApplicationController
  def index

  end
  def health

  end
  def education

  end
  def livelihood

  end
  def social

  end
  def empowerment

  end
end
