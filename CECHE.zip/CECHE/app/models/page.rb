class Page < ApplicationRecord
  
end
