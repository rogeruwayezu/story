class Subscription < ApplicationRecord
end
