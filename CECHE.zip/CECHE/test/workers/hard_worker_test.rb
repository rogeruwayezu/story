require 'test_helper'
class HardWorkerTest < MiniTest::Unit::TestCase
  def test_example
    skip "add some examples to (or delete) #{__FILE__}"
  end
end
