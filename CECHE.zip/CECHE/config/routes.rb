Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  get "/", to: 'pages#index'
  get "/signup", to: 'users#new'
  post "/users", to: 'users#create'
  get "/education", to: 'pages#education'
  get "/empowerment", to: 'pages#empowerment'
  get "/health", to: 'pages#health'
  get "/livelihood", to: 'pages#livelihood'
  get "social", to: 'pages#social' 
  get "/reports", to: 'reports#new'
  post "/reports", to: 'reports#create'
  get "/reports/:id", to: 'reports#show'
end
