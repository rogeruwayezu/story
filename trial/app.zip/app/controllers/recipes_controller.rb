class RecipesController < ApplicationController
  def index

  end
end
